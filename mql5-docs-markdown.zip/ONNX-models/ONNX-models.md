# ONNX models

ONNX Models in Machine Learning

[ONNX](https://onnx.ai/) (Open Neural Network Exchange) is an open-source format for machine learning models. This project has several major advantages:

- [ONNX](ONNX-Support/ONNX-Support.md) is supported by large companies such as Microsoft, Facebook, Amazon and other partners.
- Its open format enables [format conversions](Format-Conversion/Format-Conversion.md) between different machine learning toolkits, while Microsoft's [ONNXMLTools](https://learn.microsoft.com/ru-ru/windows/ai/windows-ml/onnxmltools) allows converting models to the ONNX format.
- MQL5 provides [automatic data type conversion](Automatic-data-type-conversion/Automatic-data-type-conversion.md) for model inputs and outputs if the passed parameter type does not match the model.
- [ONNX models](Creating-a-Model/Creating-a-Model.md) can be created using various machine learning tools. They are currently supported in Caffe2, Microsoft Cognitive Toolkit, MXNet, PyTorch and OpenCV. Interfaces for other popular frameworks and libraries are also available.
- With the MQL5 language, you can implement an [ONNX model in a trading strategy](Running-a-model/Running-a-model.md) and use it along with all the advantages of the MetaTrader 5 platform for efficient operations in the financial markets.
- Before tunning a model for live trading, you can [test the model behavior on historical data](Validation-in-the-Strategy-Tester/Validation-in-the-Strategy-Tester.md) in the Strategy Tester, without using third-party tools.

MQL5 provides the following functions for working with ONNX:

| Function | Action |
| --- | --- |
| [OnnxCreate](OnnxCreate/OnnxCreate.md) | Create an ONNX session, loading a model from an \*.onnx file |
| [OnnxCreateFromBuffer](OnnxCreateFromBuffer/OnnxCreateFromBuffer.md) | Create an ONNX session, loading a model from a data array |
| [OnnxRelease](OnnxRelease/OnnxRelease.md) | Close an ONNX session |
| [OnnxRun](OnnxRun/OnnxRun.md) | Run an ONNX model |
| [OnnxGetInputCount](OnnxGetInputCount/OnnxGetInputCount.md) | Get the number of inputs in an ONNX model |
| [OnnxGetOutputCount](OnnxGetOutputCount/OnnxGetOutputCount.md) | Get the number of outputs in an ONNX model |
| [OnnxGetInputName](OnnxGetInputName/OnnxGetInputName.md) | Get the name of a model's input by index |
| [OnnxGetOutputName](OnnxGetOutputName/OnnxGetOutputName.md) | Get the name of a model's output by index |
| [OnnxGetInputTypeInfo](OnnxGetInputTypeInfo/OnnxGetInputTypeInfo.md) | Get the description of the input type from the model |
| [OnnxGetOutputTypeInfo](OnnxGetOutputTypeInfo/OnnxGetOutputTypeInfo.md) | Get the description of the output type from the model |
| [OnnxSetInputShape](OnnxSetInputShape/OnnxSetInputShape.md) | Set the shape of a model's input data by index |
| [OnnxSetOutputShape](OnnxSetOutputShape/OnnxSetOutputShape.md) | Set the shape of a model's output data by index |
