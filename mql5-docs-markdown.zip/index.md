# MQL5 Reference

MQL5 Reference

MetaQuotes Language 5 (MQL5) is a high-level language designed for developing technical indicators, trading robots and utility applications, which automate financial trading. MQL5 has been developed by [MetaQuotes](https://www.metaquotes.net) for their trading platform. The language syntax is very close to C++ enabling programmers to develop applications in the object-oriented programming (OOP) style.

In addition to the MQL5 language, the trading platform package also includes the [MetaEditor IDE](https://www.metatrader5.com/en/metaeditor/help) with highly advanced code writing tools, such as templates, snippets, debugging, profiling and auto completion tools, as well as built-in [MQL5 Storage](https://www.metatrader5.com/en/metaeditor/help/mql5storage) enabling file versioning.

The language support is available on the MQL5 Algotrading community website, which contains a huge [free CodeBase](https://www.mql5.com/en/code) and a plethora of [articles](https://www.mql5.com/en/articles). These articles cover all the aspects of the modern trading, including neural networks, statistics and analysis, high-frequency trading, arbitrage, testing and optimization of trading strategies, use of trading automation robots, and more.

Traders and MQL5 program developers can communicate on the forum, order and develop applications using the [Freelance](https://www.mql5.com/en/job) service, as well as buy and sell protected programs in the [Market](https://www.mql5.com/en/market) of automated trading applications.

The MQL5 language provides specialized [trading functions](Trade-Functions/Trade-Functions.md) and predefined [event handlers](Language-Basics/Functions/Event-Handling-Functions/Event-Handling-Functions.md) to help programmers develop Expert Advisors (EAs), which automatically control trading processes following specific trading rules. In addition to EAs, MQL5 allows developing custom [technical indicators](Custom-Indicators/Custom-Indicators.md), scripts and libraries.

This MQL5 language reference contains functions, operations, reserved words and other language constructions divided into categories. The reference also provides descriptions of [Standard Library](Standard-Library/Standard-Library.md) classes used for developing trading strategies, control panels, custom graphics and enabling file access.

Additionally, the CodeBase contains the [ALGLIB](https://www.mql5.com/en/code/1146) numerical analysis library, which can be used for solving various mathematical problems.

 

Algo Trading Books

Starting to learn something new is always challenging. To assist beginners, we have released two comprehensive books on MQL5 programming, designed for anyone who wish to master the creation of trading robots and applications for algorithmic trading.

These books offer a systematic and structured presentation of the material to make the learning process significantly easier. Detailed code examples, which explain the step-by-step creation of trading robots and applications, allow for a deeper understanding of algorithmic trading nuances. The books include numerous practical exercises to help reinforce the acquired knowledge and develop programming skills in real trading environments.

["MQL5 Programming for Traders](https://www.mql5.com/en/book "MQL5 Tutorial")" is the most complete and detailed tutorial on MQL5, suitable for programmers of all levels. Beginners will learn the basics: the book introduces development tools and basic programming concepts. Based on this material, you will create, compile and run your first application in the MetaTrader 5 trading platform. Users with experience in other programming languages can immediately proceed to the application part: creating trading robots and analytical applications in MQL5.

["Neural Networks for Algorithmic Trading with MQL5](https://www.mql5.com/en/neurobook "Book on Neural Networks with MQL5, OpenCL and Python")" is a guide to using machine learning methods in trading robots for the MetaTrader 5 platform. You will be progressively introduced to the fundamentals of neural networks and their application in algorithmic trading. As you advance, you will build and train your own AI solution, gradually adding new features. In addition to learning MQL5, you will gain Python and OpenCL programming skills and explore integrated matrix and vector methods, which enable the solution of complex mathematical problems with concise and efficient code.

 

Articles on the development of trading applications

MQL5 Articles are an excellent resource for exploring the full potential of the language, covering a wide range of practical algorithmic trading tasks. For easy navigation, all articles are categorized into sections such as [Example](https://www.mql5.com/en/articles/examples), [Expert Advisors](https://www.mql5.com/en/articles/expert_advisors), [Machine Learning](https://www.mql5.com/en/articles/machine_learning) and more. Every month, dozens of new articles are published on the [MQL5 Algotrading community](https://www.mql5.com/) website, written by traders for other traders. Read and discuss these articles to master modern algorithmic trading. For beginners, we have compiled a list of [16 recommended articles](https://www.metatrader5.com/en/metaeditor/help/articles) for a quick immersion into MQL5.  
 

Types of MQL5 Applications

MQL5 programs are divided into five specialized types based on the trading automation tasks that they implement:

- Expert Advisor is an automated trading system linked to a chart. An Expert Advisor contains [event](Language-Basics/Functions/Event-Handling-Functions/Event-Handling-Functions.md) handlers to manage predefined events which activate execution of appropriate trading strategy elements. For example, an event of program initialization and deinitializtion, new ticks, timer events, changes in the Depth of Market, chart and custom events.  
  In addition to calculating trading signals based on the implemented rules, Expert Advisors can also automatically execute trades and send them directly to a trading server. Expert Advisors are stored in <Terminal\_Directory>\MQL5\Experts.
- Custom Indicators is a technical indicator developed by a user in addition to standard indicators integrated into the trading platform. Custom indicators, as well as standard ones, cannot trade automatically, but only implement analytical functions. Custom indicators can utilize values of other indicators for calculations, and can be called from Expert Advisors.  
  Custom indicators are stored in <Terminal\_Directory>\MQL5\Indicators.
- Script is a program for a single execution of an action. Unlike Expert Advisors, scripts do not handle any event except for trigger. A script code must contain the OnStart handler function.  
  Scripts are stored in <Terminal\_DIrectory>\MQL5\Scripts.

- Service is a program that, unlike indicators, Expert Advisors and scripts, does not require to be bound to a chart to work. Like scripts, services do not handle any event except for trigger. To launch a service, its code should contain the OnStart handler function. Services do not accept any other events except Start, but they are able to send custom events to charts using [EventChartCustom](Working-with-Events/EventChartCustom/EventChartCustom.md). Services are stored in <terminal\_directory>\MQL5\Services.

- Library is a set of custom functions. Libraries are intended to store and distribute commonly used algorithms of custom programs.  
  Libraries are stored in <Terminal\_Directory>\MQL5\Libraries.
- Include File is a source text of the most frequently used blocks of custom programs. Such files can be included into the source texts of Expert Advisors, scripts, custom indicators, and libraries at the compiling stage. The use of included files is more preferable than the use of libraries because of additional burden occurring at calling library functions.   
  Include files can be stored in the same directory where the original file is located. In this case the [#include](Language-Basics/Preprocessor/Including-Files-(#include)/Including-Files-(#include).md) directive with double quotes is used. Another option is to store include files in <Terminal\_Directory>\MQL5\Include. In this case #include with angle brackets should be used.

 

© 2000-2026, [MetaQuotes Ltd.](https://www.metaquotes.net)
