# Norm

Norm

Return matrix or vector norm.

|  |
| --- |
| double vector::Norm(    const ENUM\_VECTOR\_NORM  norm,     // vector norm    const int                        norm\_p=2  // number of p-norm in case of VECTOR\_NORM\_P     );     double matrix::Norm(    const ENUM\_MATRIX\_NORM  norm      // matrix norm     ); |

Parameters

norm

[in] Norm order

Return Value

Matrix or vector norm.

 

Note

- VECTOR\_NORM\_INF is the maximum absolute value among vector elements.
- VECTOR\_NORM\_MINUS\_INF is the minimum absolute value of a vector.
- VECTOR\_NORM\_P is the P-norm of the vector. If norm\_p=0, then this is the number of non-zero vector elements. norm\_p=1 is the sum of absolute values of vector elements. norm\_p=2 is the square root of the sum of squares of vector element values. The value of the norm\_p parameter can be negative.
- MATRIX\_NORM\_FROBENIUS is the square root of the sum of the squares of the matrix element values. The Frobenius norm and the vector P2-norm are consistent.
- MATRIX\_NORM\_SPECTRAL is the maximum value of the matrix spectrum.
- MATRIX\_NORM\_NUCLEAR is the sum of the singular values of the matrix.
- MATRIX\_NORM\_INF is the maximum vector p1-norm among the vertical vectors of the matrix. The matrix inf-norm and the vector inf-norm are consistent.
- MATRIX\_NORM\_MINUS\_INF is the minimum vector p1-norm among the vertical vectors of the matrix.
- MATRIX\_NORM\_P1 is the maximum vector p1-norm among horizontal matrix vectors.
- MATRIX\_NORM\_MINUS\_P1 is the minimum vector p1-norm among horizontal matrix vectors.
- MATRIX\_NORM\_P2 is the highest singular value of the matrix.
- MATRIX\_NORM\_MINUS\_P2 is the lowest singular value of a matrix.

 

A simple algorithm for calculating the P-norm of a vector in MQL5:

|  |
| --- |
| double VectorNormP(const vector& v,int norm\_value)    {     ulong  i;     double norm=0.0;  //---     switch(norm\_value)       {        case 0 :           for(i=0; i<v.Size(); i++)              if(v[i]!=0)                 norm+=1.0;           break;        case 1 :           for(i=0; i<v.Size(); i++)              norm+=MathAbs(v[i]);           break;        case 2 :           for(i=0; i<v.Size(); i++)              norm+=v[i]\*v[i];           norm=MathSqrt(norm);           break;        default :           for(i=0; i<v.Size(); i++)              norm+=MathPow(MathAbs(v[i]),norm\_value);           norm=MathPow(norm,1.0/norm\_value);       }  //---     return(norm);    } |

MQL5 example:

|  |
| --- |
| matrix a= {{0, 1, 2, 3, 4, 5, 6, 7, 8}};    a=a-4;    Print("matrix a \n", a);    a.Reshape(3, 3);    matrix b=a;    Print("matrix b \n", b);    Print("b.Norm(MATRIX\_NORM\_P2)=", b.Norm(MATRIX\_NORM\_FROBENIUS));    Print("b.Norm(MATRIX\_NORM\_FROBENIUS)=", b.Norm(MATRIX\_NORM\_FROBENIUS));    Print("b.Norm(MATRIX\_NORM\_INF)", b.Norm(MATRIX\_NORM\_INF));    Print("b.Norm(MATRIX\_NORM\_MINUS\_INF)", b.Norm(MATRIX\_NORM\_MINUS\_INF));    Print("b.Norm(MATRIX\_NORM\_P1)=)", b.Norm(MATRIX\_NORM\_P1));    Print("b.Norm(MATRIX\_NORM\_MINUS\_P1)=", b.Norm(MATRIX\_NORM\_MINUS\_P1));    Print("b.Norm(MATRIX\_NORM\_P2)=", b.Norm(MATRIX\_NORM\_P2));    Print("b.Norm(MATRIX\_NORM\_MINUS\_P2)=", b.Norm(MATRIX\_NORM\_MINUS\_P2));       /\*    matrix a    [[-4,-3,-2,-1,0,1,2,3,4]]    matrix b    [[-4,-3,-2]    [-1,0,1]    [2,3,4]]    b.Norm(MATRIX\_NORM\_P2)=7.745966692414834    b.Norm(MATRIX\_NORM\_FROBENIUS)=7.745966692414834    b.Norm(MATRIX\_NORM\_INF)9.0    b.Norm(MATRIX\_NORM\_MINUS\_INF)2.0    b.Norm(MATRIX\_NORM\_P1)=)7.0    b.Norm(MATRIX\_NORM\_MINUS\_P1)=6.0    b.Norm(MATRIX\_NORM\_P2)=7.348469228349533    b.Norm(MATRIX\_NORM\_MINUS\_P2)=1.857033188519056e-16    \*/ |

Python example:

|  |
| --- |
| import numpy as np  from numpy import linalg as LA  a = np.arange(9) - 4  print("a \n",a)  b = a.reshape((3, 3))  print("b \n",b)  print("LA.norm(b)=",LA.norm(b))  print("LA.norm(b, 'fro')=",LA.norm(b, 'fro'))  print("LA.norm(b, np.inf)=",LA.norm(b, np.inf))  print("LA.norm(b, -np.inf)=",LA.norm(b, -np.inf))  print("LA.norm(b, 1)=",LA.norm(b, 1))  print("LA.norm(b, -1)=",LA.norm(b, -1))  print("LA.norm(b, 2)=",LA.norm(b, 2))  print("LA.norm(b, -2)=",LA.norm(b, -2))     a    [-4 -3 -2 -1  0  1  2  3  4]  b    [[-4 -3 -2]   [-1  0  1]   [ 2  3  4]]  LA.norm(b)= 7.745966692414834  LA.norm(b, 'fro')= 7.745966692414834  LA.norm(b, np.inf)= 9.0  LA.norm(b, -np.inf)= 2.0  LA.norm(b, 1)= 7.0  LA.norm(b, -1)= 6.0  LA.norm(b, 2)= 7.3484692283495345  LA.norm(b, -2)= 1.857033188519056e-16 |
