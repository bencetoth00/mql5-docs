# Correlate

Correlate

Compute the cross-correlation of two vectors.

|  |
| --- |
| vector vector::Correlate(    const vector&          v,        // vector    ENUM\_VECTOR\_CONVOLVE   mode      // mode     ); |

Parameters

v

[in]  Second vector.

mode

[in]  The 'mode' parameter determines the linear convolution calculation mode. Value from the [ENUM\_VECTOR\_CONVOLVE](../../Matrix-and-Vector-Types/Enumerations/Enumerations.md#enum_vector_convolve) enumeration.

Return Value

Cross-correlation of two vectors.

Note

The 'mode' parameter determines the linear convolution calculation mode.

 

A simple algorithm for calculating the correlation coefficient of two vectors using MQL5:

|  |
| --- |
| vector VectorCrossCorrelationFull(const vector& a,const vector& b)    {     int    m=(int)a.Size();     int    n=(int)b.Size();     int    size=m+n-1;     vector c=vector::Zeros(size);        for(int i=0; i<n; i++)        for(int i\_=i; i\_<i+m; i\_++)           c[i\_]+=b[n-i-1]\*a[i\_-i];        return(c);    }  //+------------------------------------------------------------------+  //|                                                                  |  //+------------------------------------------------------------------+  vector VectorCrossCorrelationSame(const vector& a,const vector& b)    {     int    m=(int)a.Size();     int    n=(int)b.Size();     int    size=MathMax(m,n);     vector c=vector::Zeros(size);        for(int i=0; i<n; i++)       {        for(int i\_=i; i\_<i+m; i\_++)          {           int k=i\_-size/2+1;           if(k>=0 && k<size)              c[k]+=b[n-i-1]\*a[i\_-i];          }       }        return(c);    }  //+------------------------------------------------------------------+  //|                                                                  |  //+------------------------------------------------------------------+  vector VectorCrossCorrelationValid(const vector& a,const vector& b)    {     int    m=(int)a.Size();     int    n=(int)b.Size();     int    size=MathMax(m,n)-MathMin(m,n)+1;     vector c=vector::Zeros(size);        for(int i=0; i<n; i++)       {        for(int i\_=i; i\_<i+m; i\_++)          {           int k=i\_-n+1;           if(k>=0 && k<size)              c[k]+=b[n-i-1]\*a[i\_-i];          }       }        return(c);    } |

 

MQL5 example:

|  |
| --- |
| vector a={1,2,3,4,5};     vector b={0,1,0.5};        Print("full\n",a.Correlate(b,VECTOR\_CONVOLVE\_FULL));     Print("same\n",a.Correlate(b,VECTOR\_CONVOLVE\_SAME));     Print("valid\n",a.Correlate(b,VECTOR\_CONVOLVE\_VALID));     Print("full\n",b.Correlate(a,VECTOR\_CONVOLVE\_FULL));       /\*     full     [0.5,2,3.5,5,6.5,5,0]     same     [2,3.5,5,6.5,5]     valid     [3.5,5,6.5]     full     [0,5,6.5,5,3.5,2,0.5]    \*/ |

 

Python example:

|  |
| --- |
| import numpy as np  a=[1,2,3,4,5]  b=[0,1,0.5]     print("full\n",np.correlate(a,b,'full'))  print("same\n",np.correlate(a,b,'same'));  print("valid\n",np.correlate(a,b,'valid'));  print("full\n",np.correlate(b,a,'full'))     full   [0.5 2.  3.5 5.  6.5 5.  0. ]  same   [2.  3.5 5.  6.5 5. ]  valid   [3.5 5.  6.5]  full   [0.  5.  6.5 5.  3.5 2.  0.5] |
