# TimeTradeServer

TimeTradeServer

Returns the calculated current time of the trade server. Unlike [TimeCurrent()](../TimeCurrent/TimeCurrent.md), the calculation of the time value is performed in the client terminal and depends on the time settings on your computer. There are 2 variants of the function.

Call without parameters

|  |
| --- |
| datetime  TimeTradeServer(); |

Call with MqlDateTime type parameter

|  |
| --- |
| datetime  TimeTradeServer(     MqlDateTime&  dt\_struct      // Variable of structure type     ); |

Parameters

dt\_struct

[out]  Variable of structure type [MqlDateTime](../../Constants,-Enumerations-and-Structures/Data-Structures/Date-Type-Structure/Date-Type-Structure.md).

Return Value

Value of [datetime](../../Language-Basics/Data-Types/Integer-Types/Datetime-Type/Datetime-Type.md) type

Note

If the MqlDateTime structure type variable has been passed as a parameter, it is filled accordingly.

To arrange high-resolution counters and timers, use the [GetTickCount()](../../Common-Functions/GetTickCount/GetTickCount.md) function, which produces values in milliseconds.

During testing in the strategy tester, TimeTradeServer() is simulated according to historical data and always equal to [TimeCurrent()](../TimeCurrent/TimeCurrent.md).

Example:

|  |
| --- |
| void OnStart()    {  //--- declare the MqlDateTime variable to be filled with date/time data and get the time of the last quote and the estimated current time of the trade server     MqlDateTime tm={};     datetime    time\_current=TimeCurrent();                  // first form of call: time of the last quote for one of the symbols in the Market Watch window     datetime    time\_server =TimeTradeServer(tm);            // second form of call: estimated current time of the trade server with filling in the MqlDateTime structure     int         difference  =int(time\_current-time\_server);  // difference between Time Current and Time Trade Server       //--- display the time of the last quote and the estimated current time of the trade server with the data of the filled MqlDateTime structure in the log     PrintFormat("Time Current: %s\nTime Trade Server: %s\n- Year: %u\n- Month: %02u\n- Day: %02u\n"+                 "- Hour: %02u\n- Min: %02u\n- Sec: %02u\n- Day of Year: %03u\n- Day of Week: %u (%s)\nDifference between Time Current and Time Trade Server: %+d",                 (string)time\_current, (string)time\_server, tm.year, tm.mon, tm.day, tm.hour, tm.min, tm.sec, tm.day\_of\_year, tm.day\_of\_week,                 EnumToString((ENUM\_DAY\_OF\_WEEK)tm.day\_of\_week), difference);     /\*     result:     Time Current: 2024.04.18 16:10:14     Time Trade Server: 2024.04.18 16:10:15     - Year: 2024     - Month: 04     - Day: 18     - Hour: 16     - Min: 10     - Sec: 15     - Day of Year: 108     - Day of Week: 4 (THURSDAY)     Difference between Time Current and Time Trade Server: -1     \*/    } |
